import 'package:flutter/material.dart';

class Parkir extends StatefulWidget {
  @override
  _ParkirState createState() => _ParkirState();
}

class _ParkirState extends State<Parkir> {
  String dropdown1Value = 'A1';

  @override
  Widget build(BuildContext context) {
    return Container(
        child: Column(
      // mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        const Image(
          image: NetworkImage(
              'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ28Z6By6glfahzwosbJD6dw54K-AQeDgflkLp4HK6iAmfhF2Wo'),
          width: 430.5,
        ),
        SizedBox(
          height: 310,
          child: Card(
            child: Column(
              children: [
                ListTile(
                  title: Text('Pilih Lokasi Parkir :',
                      style: TextStyle(fontWeight: FontWeight.w500)),
                  leading: Icon(
                    Icons.local_parking,
                    color: Colors.red,
                  ),
                ),
                ListTile(
                  title: const Text('Slot yang tersedia :'),
                  trailing: DropdownButton<String>(
                    value: dropdown1Value,
                    onChanged: (String newValue) {
                      setState(() {
                        dropdown1Value = newValue;
                      });
                    },
                    items: <String>['A1', 'A2', 'A3', 'A4', 'A5', 'A6']
                        .map<DropdownMenuItem<String>>((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(value),
                      );
                    }).toList(),
                  ),
                ),
                const SizedBox(
                  height: 5.0,
                ),
                Divider(),
                ListTile(
                  title: Text('Waktu Parkir :',
                      style: TextStyle(fontWeight: FontWeight.w500)),
                  leading: Icon(
                    Icons.timer,
                    color: Colors.red,
                  ),
                ),
                Divider(),
                ListTile(
                  title: Text('Total Biaya :',
                      style: TextStyle(fontWeight: FontWeight.w500),),
                  leading: Icon(
                    Icons.shopping_cart,
                    color: Colors.red,
                  ),
                ),
              ],
            ),
          ),
        )
        
      ],
    ));
  }
}
